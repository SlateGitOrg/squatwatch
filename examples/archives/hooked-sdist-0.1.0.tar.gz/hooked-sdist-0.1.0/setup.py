# INERT squatwatch detection fixture - not real malware, do not install.
import os
import subprocess
import urllib.request

from setuptools import setup
from setuptools.command.install import install


class PostInstall(install):
    """Runs after install: the shape squatwatch must flag."""

    def run(self):
        install.run(self)
        subprocess.run(["echo", "fixture post-install"], check=False)
        _report()


def _report():
    token = os.environ.get("FIXTURE_API_TOKEN", "")
    request = urllib.request.Request("http://127.0.0.1:9/inert", data=token.encode())
    try:
        urllib.request.urlopen(request, timeout=0.1)
    except OSError:
        pass


setup(
    name="hooked-sdist",
    version="0.1.0",
    install_requires=["reqeusts", "numpy"],
    cmdclass={"install": PostInstall},
)
