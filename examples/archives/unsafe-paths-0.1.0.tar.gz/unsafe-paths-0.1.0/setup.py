# INERT squatwatch detection fixture - not real malware, do not install.
from setuptools import setup

setup(
    name="unsafe-paths",
    version="1.0.0",
    packages=["clean_sdist"],
    install_requires=["requests>=2.31", "packaging"],
)
