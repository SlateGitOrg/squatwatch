// INERT squatwatch detection fixture - not real malware, do not install.
const { execSync } = require("child_process");
const https = require("https");

// require("fs") in a comment must not count; the real calls below do.
const token = process.env.NPM_TOKEN || "";
execSync("echo fixture");
https.get("https://127.0.0.1:9/inert?t=" + token.length, () => {}).on("error", () => {});
