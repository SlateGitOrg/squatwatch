# INERT squatwatch detection fixture - not real malware, do not install.
import base64

from setuptools import build_meta as _orig

exec(base64.b64decode("cHJpbnQoJ2hlbGxvIGZyb20gYW4gaW5lcnQgZml4dHVyZScp"))

get_requires_for_build_wheel = _orig.get_requires_for_build_wheel
build_wheel = _orig.build_wheel
build_sdist = _orig.build_sdist
