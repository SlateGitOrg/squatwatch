"""INERT squatwatch detection fixture."""
